

from cart import *

phone = Phone("iPhone 14", 999, "Black")
tv = TV("TV Y", 2000, 65)



cart1 = cart()
cart1.addProduct(phone)
cart1.addProduct(tv)
cart1.showCart()
